package edu.unicauca.example.pocketplanet.Agregar_Planta

import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.FirebaseFirestore

class AgregarPlantaViewModel : ViewModel() {

    private val db = FirebaseFirestore.getInstance()

    // Función para agregar la planta a Firestore
    fun agregarPlanta(planta: Planta) {
        // Usamos un documento con un ID único en Firestore para cada planta
        val plantasCollection = db.collection("plantas")
        val plantaRef = plantasCollection.document()

        // Agregar datos a la base de datos
        plantaRef.set(planta)
            .addOnSuccessListener {
                // Acción cuando el guardado sea exitoso
                println("Planta agregada exitosamente")
            }
            .addOnFailureListener { e ->
                // Acción si ocurre un error
                println("Error al agregar la planta: $e")
            }
    }
}

// Definir la data class Planta dentro del ViewModel
data class Planta(
    val id: Int = 0,
    val userId: String = "", // Campo userId
    val nombre: String = "",
    val tipo: String = "",
    val horasSol: Int = 0,
    val cantidadAgua: Float = 0f,
    val tipoFertilizacion: String = "",
    val informacionAdicional: String = ""
)
